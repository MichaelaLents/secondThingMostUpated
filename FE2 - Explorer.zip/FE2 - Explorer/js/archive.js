(function() {
  'use strict';

  var jsonURL = 'https://credentials-api.generalassemb.ly/explorer/posts';
})();
